const express = require("express");
const fs = require("fs/promises");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3001;
const ROOT_DIR = __dirname;
const CARDS_DIR = path.join(ROOT_DIR, "cards");

function buildStamp() {
  const now = new Date();
  const pad = (value, size = 2) => String(value).padStart(size, "0");
  const datePart = [now.getFullYear(), pad(now.getMonth() + 1), pad(now.getDate())].join("-");
  const timePart = [
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds()),
    pad(now.getMilliseconds(), 3)
  ].join("-");
  return `${datePart}_${timePart}`;
}

function buildSubscriptionText(payload) {
  return [
    "Discord Subscription Purchase",
    "---------------------------",
    `Created at: ${new Date().toISOString()}`,
    `Plan: ${payload.plan}`,
    `Email: ${payload.email}`,
    `Discord tag: ${payload.discordTag}`,
    `Payment card: ${payload.cardNumber}`,
    `About purchase: ${payload.note || "-"}`,
    "---------------------------"
  ].join("\n");
}

app.use(express.json());
app.use(express.static(ROOT_DIR));

app.post("/api/subscription", async (req, res) => {
  try {
    const plan = String(req.body?.plan || "").trim();
    const email = String(req.body?.email || "").trim();
    const discordTag = String(req.body?.discordTag || "").trim();
    const cardNumber = String(req.body?.cardNumber || "").trim();
    const note = String(req.body?.note || "").trim();

    if (!plan || !email || !discordTag || !cardNumber) {
      return res.status(400).json({
        ok: false,
        message: "Plan, email, Discord tag and card number are required."
      });
    }

    await fs.mkdir(CARDS_DIR, { recursive: true });

    const stamp = buildStamp();
    const fileName = `subscription-${stamp}.txt`;
    const filePath = path.join(CARDS_DIR, fileName);
    const fileContent = buildSubscriptionText({ plan, email, discordTag, cardNumber, note });

    await fs.writeFile(filePath, fileContent, "utf8");

    return res.json({
      ok: true,
      message: "Subscription data saved.",
      fileName,
      fileContent
    });
  } catch (error) {
    console.error("Failed to save subscription:", error);
    return res.status(500).json({ ok: false, message: "Failed to save subscription." });
  }
});

app.get("/checkout", (_req, res) => {
  res.sendFile(path.join(ROOT_DIR, "checkout.html"));
});

app.listen(PORT, () => {
  console.log(`Discord project started on http://localhost:${PORT}`);
});
